<?php
// index.php at project root (NOT inside public/)

require_once __DIR__ . '/src/layout.php';

$content = '
<div class="bg-light py-5">
  <div class="container text-center">
    <h1 class="display-4 fw-bold text-primary mb-3">
      <i class="bi bi-speedometer2"></i> Smart Gas Metering & Alert System
    </h1>
    <p class="lead text-muted mb-5">
      Real-Time Monitoring for Safety, Convenience, and Budget Control
    </p>
    <a href="public/login.php" class="btn btn-lg btn-success shadow-sm px-5">
      <i class="bi bi-box-arrow-in-right"></i> Proceed to Login
    </a>
  </div>
</div>

<div class="container py-5">
  <div class="row g-4">

    <div class="col-md-6">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body">
          <h3 class="card-title text-primary">1. Problem Definition</h3>
          <p class="card-text">
            In many households and businesses, gas runs out unexpectedly—leading to half-cooked meals, frustrated families,
            or costly business interruptions. This unpredictability disrupts budgets and causes unnecessary stress.
          </p>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body">
          <h3 class="card-title text-primary">2. Proposed Solution</h3>
          <p class="card-text">
            Our system continuously monitors gas levels and provides alerts well before depletion.
            With real-time tracking, users can plan ahead, avoid surprises, and manage budgets efficiently.
          </p>
        </div>
      </div>
    </div>

    <div class="col-md-12">
      <div class="card h-100 shadow-sm border-0 mt-4">
        <div class="card-body">
          <h3 class="card-title text-primary">3. How It Works</h3>
          <ul class="list-group list-group-flush">
            <li class="list-group-item"><b>Gas Level Tracking:</b> Sensor measures gas level in %.</li>
            <li class="list-group-item"><b>Dashboard:</b> Progress bar shows safe, refill-soon, or danger zones.</li>
            <li class="list-group-item"><b>Smart Alerts:</b> Notifications when thresholds are crossed.</li>
            <li class="list-group-item"><b>Refill Logging:</b> Users can log a refill instantly.</li>
          </ul>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card h-100 shadow-sm border-0 mt-4">
        <div class="card-body">
          <h3 class="card-title text-primary">4. Monetization Plan</h3>
          <p class="card-text">
            Partnerships with gas distributors, regulators, and energy agencies.
            Licensing per unit or revenue-sharing from gas sales tracked through the platform.
          </p>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card h-100 shadow-sm border-0 mt-4">
        <div class="card-body">
          <h3 class="card-title text-primary">5. Challenges & Solutions</h3>
          <ul>
            <li><b>Sensor Accuracy:</b> Calibrated sensors with averaging algorithms.</li>
            <li><b>Connectivity:</b> GSM + offline backup mode.</li>
            <li><b>User Adoption:</b> Trial period and strong marketing of benefits.</li>
          </ul>
        </div>
      </div>
    </div>

  </div>

  <div class="text-center mt-5">
    <a href="public/login.php" class="btn btn-lg btn-primary px-5">
      <i class="bi bi-box-arrow-in-right"></i> Get Started
    </a>
  </div>
</div>
';

renderLayout("Welcome", $content);
