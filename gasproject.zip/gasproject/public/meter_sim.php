<?php
require_once __DIR__ . '/../src/db.php';

// Fetch the latest meter
$result = $conn->query("SELECT * FROM gas_meter ORDER BY id DESC LIMIT 1");
if (!$result || $result->num_rows === 0) exit;

$row = $result->fetch_assoc();
$current = (int)$row['current_level'];
$lastNotified = $row['last_notified'] ? explode(',', $row['last_notified']) : [];

if ($current <= 0) exit;

// Simulate gas consumption
$consumed = rand(1, 6);
$newLevel = max(0, $current - $consumed);

// Determine thresholds (you can define these anywhere, for example 25%, 50%, 75%)
$thresholds = [25, 50, 75];
$messages = [];

// Check if a threshold is crossed
foreach ($thresholds as $t) {
    if ($newLevel <= $t && !in_array((string)$t, $lastNotified) && $current > $t) {
        $messages[] = "Alert: Gas level is at $t% or below. Please refill soon.";
        $lastNotified[] = $t;
    }
}

// Update the gas_meter table
$updatedNotified = implode(',', $lastNotified);
$stmt = $conn->prepare("INSERT INTO gas_meter (current_level, last_notified, updated_at) VALUES (?, ?, NOW())");
$stmt->bind_param("is", $newLevel, $updatedNotified);
$stmt->execute();
$stmt->close();

// Optional: Output messages
if ($messages) {
    foreach ($messages as $msg) echo $msg . "\n";
}
