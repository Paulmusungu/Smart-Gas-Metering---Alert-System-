<?php
require __DIR__ . '/../../src/db.php';

$result = $conn->query("SELECT reading_time, gas_level FROM gas_meter ORDER BY reading_time DESC LIMIT 20");

$labels = [];
$values = [];

while ($row = $result->fetch_assoc()) {
    $labels[] = $row['reading_time'];
    $values[] = $row['gas_level'];
}

echo json_encode([
    "labels" => array_reverse($labels),
    "values" => array_reverse($values)
]);
