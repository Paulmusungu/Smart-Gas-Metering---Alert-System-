<?php
session_start();
require_once dirname(__DIR__) . '/src/db.php';
require_once dirname(__DIR__) . '/src/layout.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['logged_in'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$success = '';
$error   = '';

// ✅ Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = $_POST['name'] ?? '';
    $location = $_POST['location'] ?? '';
    $phone    = $_POST['phone'] ?? '';
    $email    = $_POST['email'] ?? '';

    if (empty($name) || empty($location) || empty($phone) || empty($email)) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("UPDATE members 
                                SET name = ?, location = ?, phone = ?, email = ?, updated_at = NOW() 
                                WHERE id = ?");
        $stmt->bind_param("ssssi", $name, $location, $phone, $email, $userId);
        if ($stmt->execute()) {
            $success = "✅ Account updated successfully!";
            // Update session values so sidebar reflects changes
            $_SESSION['username'] = $name;
        } else {
            $error = "Error updating account: " . $stmt->error;
        }
        $stmt->close();
    }
}

// ✅ Fetch latest account info
$stmt = $conn->prepare("SELECT name, location, phone, email, meter_no, created_at, updated_at 
                        FROM members WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->bind_result($name, $location, $phone, $email, $meter_no, $created_at, $updated_at);
$stmt->fetch();
$stmt->close();

// ✅ Build page content
$content = '<h4>Update your account details and preferences</h4>';

if ($success) $content .= '<div class="alert alert-success">'.$success.'</div>';
if ($error)   $content .= '<div class="alert alert-danger">'.$error.'</div>';

$content .= '
<form method="POST" class="row g-3">
  <div class="col-md-6">
    <label class="form-label">Name</label>
    <input type="text" name="name" class="form-control" value="'.htmlspecialchars($name).'" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Location</label>
    <input type="text" name="location" class="form-control" value="'.htmlspecialchars($location).'" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Phone</label>
    <input type="text" name="phone" class="form-control" value="'.htmlspecialchars($phone).'" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Email</label>
    <input type="email" name="email" class="form-control" value="'.htmlspecialchars($email).'" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Meter No</label>
    <input type="text" class="form-control" value="'.htmlspecialchars($meter_no).'" readonly>
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Update Account</button>
  </div>
</form>

<hr>
<p><b>Member Since:</b> '.htmlspecialchars($created_at).'</p>
<p><b>Last Updated:</b> '.htmlspecialchars($updated_at).'</p>
';

renderLayout("Account", $content);
