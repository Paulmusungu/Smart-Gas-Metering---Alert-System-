<?php
// ✅ Show errors in development (remove on production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once dirname(__DIR__) . '/src/db.php';
require_once dirname(__DIR__) . '/src/layout.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['logged_in'])) {
    header("Location: login.php");
    exit;
}

$userId  = $_SESSION['user_id'];
$error   = '';

// ✅ Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword     = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($newPassword) || empty($confirmPassword)) {
        $error = "Please fill in all fields.";
    } elseif ($newPassword !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        // ✅ Update password
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE members SET password = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $hashed, $userId);
        if ($stmt->execute()) {
            // ✅ Destroy session and redirect to login
            session_unset();
            session_destroy();
            header("Location: login.php?reset=success");
            exit;
        } else {
            $error = "Error updating password: " . $stmt->error;
        }
        $stmt->close();
    }
}

// ✅ Build page content
$content = '<h2>Change Password</h2>';
if ($error) $content .= '<div class="alert alert-danger">'.$error.'</div>';

$content .= '
<form method="POST" class="row g-3">
  <div class="col-md-6">
    <label class="form-label">New Password</label>
    <input type="password" name="new_password" class="form-control" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Confirm Password</label>
    <input type="password" name="confirm_password" class="form-control" required>
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Update Password</button>
  </div>
</form>
';

renderLayout("Change Password", $content);
