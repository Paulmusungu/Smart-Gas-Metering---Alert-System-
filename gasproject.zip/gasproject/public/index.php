<?php
session_start();
require_once __DIR__ . '/../src/db.php';
require_once __DIR__ . '/../src/layout.php';

// Fetch the latest gas meter record
$result = $conn->query("SELECT * FROM gas_meter ORDER BY id DESC LIMIT 1");

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $current_level = $row['current_level'];
    $last_notified = $row['last_notified'];
} else {
    $current_level = 0;
    $last_notified = '';
}

function getStatusMessage($level) {
    if ($level > 75) {
        return ['msg' => "You’re in the green safe zone!", 'class' => 'success'];
    } elseif ($level > 50) {
        return ['msg' => "Gas level is good, no need to refill yet.", 'class' => 'primary'];
    } elseif ($level > 30) {
        return ['msg' => "Consider refilling soon to avoid inconveniences.", 'class' => 'warning'];
    } else {
        return ['msg' => "Warning! Gas level is low, refill immediately!", 'class' => 'danger'];
    }
}

$status = getStatusMessage($current_level);

$content = "
<h2>Gas Meter Dashboard</h2>
<div class='card p-3 mb-4'>
    <h4>Current Gas Level: <span id='gas-level'>{$current_level}</span>%</h4>
    <div class='progress mb-2'>
        <div id='progress-bar' class='progress-bar bg-{$status['class']}' role='progressbar' 
            style='width: {$current_level}%' 
            aria-valuenow='{$current_level}' aria-valuemin='0' aria-valuemax='100'>
            {$current_level}%
        </div>
    </div>
    <div id='statusNote' class='alert alert-{$status['class']}'>{$status['msg']}</div>
</div>
";

renderLayout("Gas Meter", $content);
