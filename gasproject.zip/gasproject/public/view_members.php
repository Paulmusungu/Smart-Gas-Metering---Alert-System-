<?php
session_start();
require_once __DIR__ . '/../src/db.php';
require_once __DIR__ . '/../src/layout.php';

// ✅ Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../public/login.php");
    exit();
}

// ✅ Handle email update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_email'])) {
    $id = intval($_POST['id']);
    $email = trim($_POST['email']);

    if (!empty($email)) {
        $stmt = $conn->prepare("UPDATE members SET email = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $email, $id);
        if ($stmt->execute()) {
            $msg = '<div class="alert alert-success">Email updated successfully!</div>';
        } else {
            $msg = '<div class="alert alert-danger">Failed to update: '.$conn->error.'</div>';
        }
        $stmt->close();
    } else {
        $msg = '<div class="alert alert-warning">Email cannot be empty.</div>';
    }
} else {
    $msg = '';
}

// ✅ Fetch all members
$result = $conn->query("SELECT * FROM members ORDER BY id DESC");

$content = '<h2>Members List</h2>'.$msg;

if (!$result) {
    $content .= '<div class="alert alert-danger">Database query failed: '.$conn->error.'</div>';
} elseif ($result->num_rows === 0) {
    $content .= '<div class="alert alert-info">No members found.</div>';
} else {
    $content .= '<table class="table table-striped table-bordered">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Location</th>
            <th>Phone</th>
            <th>Meter No</th>
            <th>Email</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>';

    while ($row = $result->fetch_assoc()) {
        $content .= "<tr>
            <td>{$row['id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['location']}</td>
            <td>{$row['phone']}</td>
            <td>{$row['meter_no']}</td>
            <td>
                <form method='POST' class='d-flex'>
                    <input type='hidden' name='id' value='{$row['id']}'>
                    <input type='email' name='email' class='form-control form-control-sm' value='".htmlspecialchars($row['email'] ?? '')."' required>
            </td>
            <td>{$row['created_at']}</td>
            <td>{$row['updated_at']}</td>
            <td>
                    <button type='submit' name='update_email' class='btn btn-sm btn-primary'>Save</button>
                </form>
            </td>
        </tr>";
    }

    $content .= '</tbody></table>';
}

renderLayout("View Members", $content);
