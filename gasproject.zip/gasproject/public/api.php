<?php
require __DIR__ . '/src/db.php';
require __DIR__ . '/src/Meter.php';
$config = require __DIR__ . '/src/config.php';
require __DIR__ . '/src/notify.php';

if (!isset($config['notifications'])) $config['notifications'] = [];

header('Content-Type: application/json');

$meter = new Meter($pdo, $config['thresholds'], $config['notifications']);
$action = $_GET['action'] ?? '';

function getStatusMessage($level) {
    if ($level > 75) return ['msg' => "You’re in the green safe zone!", 'class' => 'success'];
    if ($level > 50) return ['msg' => "Gas level is good, no need to refill yet.", 'class' => 'primary'];
    if ($level > 30) return ['msg' => "Consider refilling soon to avoid inconveniences.", 'class' => 'warning'];
    return ['msg' => "Warning! Gas level is low, refill immediately!", 'class' => 'danger'];
}

if ($action === 'use') {
    $usage = (int)($_POST['usage'] ?? 0);
    if ($usage <= 0) { echo json_encode(['ok'=>false,'error'=>'Usage must be greater than zero']); exit; }

    $state = $meter->getState();
    $newLevel = max(0, $state['current_level'] - $usage);
    $meter->updateLevel($newLevel);

    $messages = [];
    foreach ($config['thresholds'] as $threshold) {
        if ($newLevel <= $threshold && !in_array($threshold, explode(',', $state['last_notified']))) {
            $msg = "Gas level is now at {$newLevel}% (threshold {$threshold}%)";
            sendSms($config, $msg);
            $meter->recordNotification($threshold, $msg);
            $messages[] = $msg;
        }
    }

    $status = getStatusMessage($newLevel);
    echo json_encode(['ok'=>true,'newLevel'=>$newLevel,'messages'=>$messages,'statusNote'=>$status['msg'],'statusClass'=>$status['class']]);
    exit;
}

if ($action === 'refill') {
    $meter->updateLevel(100);
    $status = getStatusMessage(100);
    echo json_encode(['ok'=>true,'newLevel'=>100,'messages'=>["Gas tank refilled to 100%. You're good to go!"],'statusNote'=>$status['msg'],'statusClass'=>$status['class']]);
    exit;
}

echo json_encode(['ok'=>false,'error'=>'Invalid action']);
