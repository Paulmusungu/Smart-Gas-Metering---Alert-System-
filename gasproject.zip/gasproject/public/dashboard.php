<?php
session_start();
require_once __DIR__ . '/../src/layout.php';

// ✅ Require login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$content = '
<div class="container py-4">
    <div class="row">
        <div class="col-lg-12 text-center mb-4">
            <h2 class="fw-bold">Welcome, ' . htmlspecialchars($_SESSION['user_name']) . '</h2>
            <p class="text-muted">Meter Number: ' . htmlspecialchars($_SESSION['user_meter']) . '</p>
        </div>
    </div>

    <!-- Dashboard Overview Cards -->
    <div class="row g-4">

        <!-- Members -->
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-lg rounded-4 dashboard-card">
                <div class="card-body text-center p-4">
                    <i class="bi bi-person-circle text-primary display-3 mb-3"></i>
                    <h5 class="fw-semibold">Members</h5>
                    <p class="text-muted small">Manage household members linked to this gas account.</p>
                    <a href="view_members.php" class="btn btn-primary btn-sm px-3">View Members</a>
                </div>
            </div>
        </div>

        <!-- Gas Levels -->
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-lg rounded-4 dashboard-card">
                <div class="card-body text-center p-4">
                    <i class="bi bi-fuel-pump-fill text-success display-3 mb-3"></i>
                    <h5 class="fw-semibold">Gas Levels</h5>
                    <p class="text-muted small">Monitor real-time gas cylinder levels and refill history.</p>
                    <a href="gas_levels.php" class="btn btn-success btn-sm px-3">Check Levels</a>
                </div>
            </div>
        </div>

        <!-- Account -->
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-lg rounded-4 dashboard-card">
                <div class="card-body text-center p-4">
                    <i class="bi bi-person-badge-fill text-warning display-3 mb-3"></i>
                    <h5 class="fw-semibold">Account</h5>
                    <p class="text-muted small">Update your account details and preferences.</p>
                    <a href="account.php" class="btn btn-warning btn-sm px-3 text-white">Manage Account</a>
                </div>
            </div>
        </div>

    </div>
</div>

<style>
.dashboard-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.dashboard-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 1rem 2rem rgba(0,0,0,0.15);
}
</style>
';

renderLayout("Dashboard", $content);
