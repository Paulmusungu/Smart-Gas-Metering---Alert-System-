<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);




session_start();
require_once dirname(__DIR__) . '/src/db.php';
require_once dirname(__DIR__) . '/src/layout.php';

$error = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $meter_no = $_POST['meter_no'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT id, name, password FROM members WHERE meter_no = ?");
    $stmt->bind_param("s", $meter_no);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $name, $hashedPassword);
        $stmt->fetch();

        if (password_verify($password, $hashedPassword)) {
            // Login successful
            $_SESSION['logged_in'] = true;
            $_SESSION['user_id'] = $id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_meter'] = $meter_no;

            // Force password change if default is still used
            if (password_verify('member123', $hashedPassword)) {
                header("Location: change_password.php");
            } else {
                header("Location: dashboard.php");
            }
            exit;
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Meter number not found.";
    }

    $stmt->close();
}

// Build page content
$content = '
<div class="d-flex justify-content-center align-items-center" style="min-height: 80vh;">
  <div class="card shadow-lg p-4" style="max-width: 450px; width: 100%;">
    <div class="card-body">
      <h3 class="text-center mb-4"></h3>';

if ($error) {
    $content .= '<div class="alert alert-danger text-center">'.$error.'</div>';
}

$content .= '
      <form method="POST" class="needs-validation" novalidate>
        <div class="mb-3">
          <label class="form-label">Meter Number</label>
          <input type="text" name="meter_no" class="form-control" placeholder="Enter your meter no." required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
        </div>
        <div class="d-grid">
          <button type="submit" class="btn btn-primary">Login</button>
        </div>
      </form>
      <p class="text-center mt-3">
        New member? <a href="add_member.php" class="btn btn-warning">Register here</a>
      </p>
    </div>
  </div>
</div>
';

renderLayout("Member Login", $content);
