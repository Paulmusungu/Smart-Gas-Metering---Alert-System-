<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once dirname(__DIR__) . '/src/db.php';
require_once dirname(__DIR__) . '/src/layout.php';

// Load PHPMailer (manual include)
require_once __DIR__ . '/../PHPMailer/src/Exception.php';
require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// ✅ Check if logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = intval($_SESSION['user_id']);

// ✅ Fetch logged in user details (include email)
$user_sql = "SELECT name, meter_no, email FROM members WHERE id = $user_id";
$user_result = $conn->query($user_sql);
$user = $user_result->fetch_assoc();

// Ensure this user has a gas meter record
$check_sql = "SELECT id FROM gas_meter WHERE user_id = $user_id LIMIT 1";
$check_result = $conn->query($check_sql);

if ($check_result->num_rows === 0) {
    $conn->query("INSERT INTO gas_meter (user_id, current_level, updated_at) VALUES ($user_id, 100, NOW())");
}

// Handle usage/refill/test email actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id'] ?? 0);
    if (isset($_POST['use'])) {
        $conn->query("UPDATE gas_meter SET current_level = GREATEST(current_level - 10, 0), updated_at = NOW() WHERE id = $id");
    }
    if (isset($_POST['refill'])) {
        $conn->query("UPDATE gas_meter SET current_level = 100, updated_at = NOW() WHERE id = $id");
    }
    if (isset($_POST['test_email'])) {
        sendGasAlert(50, $user['name'], $user['meter_no'], $user['email'], true, $id, $conn); // test email
        $_SESSION['test_msg'] = "✅ Test email sent to all recipients.";
        header("Location: gas_levels.php");
        exit();
    }
}

// Fetch gas levels for this user
$sql = "SELECT id, current_level, last_notified, updated_at 
        FROM gas_meter 
        WHERE user_id = $user_id 
        ORDER BY updated_at DESC";
$result = $conn->query($sql);

function getStatusMessage($level) {
    if ($level > 75) {
        return ['msg' => "You’re in the green safe zone!", 'class' => 'success'];
    } elseif ($level > 50) {
        return ['msg' => "Gas level is good, no need to refill yet.", 'class' => 'primary'];
    } elseif ($level > 30) {
        return ['msg' => "Consider refilling soon to avoid inconveniences.", 'class' => 'warning'];
    } else {
        return ['msg' => "⚠️ Warning! Gas level is low, refill immediately!", 'class' => 'danger'];
    }
}

// ✅ Function to send notification email (member + 4 admins)
function sendGasAlert($level, $username, $meter, $userEmail = null, $isTest = false, $meter_id = null, $conn = null) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'mail.webstack.co.ke';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'info@webstack.co.ke';
        $mail->Password   = 'Mails@2025';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        $mail->setFrom('info@webstack.co.ke', 'Gas Monitoring System');

        // ✅ Send to member email if available
        if (!empty($userEmail)) {
            $mail->addAddress($userEmail);
        }

        // ✅ Always CC these four addresses
        $recipients = [
            'musungucomps@gmail.com',
            'admin@webstack.co.ke',
            'info@webstack.co.ke',
            'williametabo@gmail.com'
        ];
        foreach ($recipients as $r) {
            $mail->addAddress($r);
        }

        $mail->isHTML(true);
        if ($isTest) {
            $mail->Subject = "✅ Test Email: Gas Monitoring System";
            $body = "This is a <strong>test email</strong>.<br>
                     Meter: $meter<br>User: $username<br>Level (simulated): $level%";
        } else {
            $mail->Subject = "⚠️ Gas Alert: Meter $meter at $level%";
            $body = "Dear $username,<br><br>
                     Your gas level has dropped to <strong>$level%</strong>.<br>
                     Please refill immediately to avoid disruption.<br><br>
                     --<br>Gas Monitoring System";
        }
        $mail->Body = $body;

        $mail->send();

        // ✅ Log to database if not test
        if (!$isTest && $conn && $meter_id) {
            $msg = $conn->real_escape_string(strip_tags($body));
            $conn->query("
                INSERT INTO notifications (meter_id, threshold, message, sent_at)
                VALUES ($meter_id, $level, '$msg', NOW())
            ");
        }

        return true;
    } catch (Exception $e) {
        error_log("Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

// ✅ Send real alert if level < 30%
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $level = $row['current_level'];
    $last_notified = $row['last_notified'];

    if ($level <= 30) {
        $should_notify = true;
        if ($last_notified) {
            $last_time = strtotime($last_notified);
            if (time() - $last_time < 3600) { // only notify once per hour
                $should_notify = false;
            }
        }
        if ($should_notify) {
            if (sendGasAlert($level, $user['name'], $user['meter_no'], $user['email'], false, $row['id'], $conn)) {
                $conn->query("UPDATE gas_meter SET last_notified = NOW() WHERE id = {$row['id']}");
            }
        }
    }
}

// Build page content
ob_start();
?>
    <h2 class="mb-3">Gas Levels</h2>

    <?php if (!empty($_SESSION['test_msg'])): ?>
        <div class="alert alert-success">
            <?= $_SESSION['test_msg']; unset($_SESSION['test_msg']); ?>
        </div>
    <?php endif; ?>

    <!-- Cylinder Styles -->
    <style>
    .cylinder {
        width: 100px;
        height: 250px;
        border: 4px solid #444;
        border-radius: 50px 50px 15px 15px;
        position: relative;
        margin: 0 auto;
        background: linear-gradient(to bottom, #e0e0e0, #cfcfcf);
        overflow: hidden;
        box-shadow: inset 0 0 10px rgba(0,0,0,0.3);
    }
    .gas-fill {
        position: absolute;
        bottom: 0;
        width: 100%;
        background: linear-gradient(to top, #28a745, #5cd65c);
        transition: height 0.6s ease-in-out;
    }
    .cylinder-label {
        font-size: 1.5rem;
        font-weight: bold;
        margin-top: 10px;
    }
    </style>

    <!-- User Info -->
    <div class="alert alert-info">
        <strong>User:</strong> <?= htmlspecialchars($user['name']) ?> |
        <strong>Meter No:</strong> <?= htmlspecialchars($user['meter_no']) ?>
    </div>

    <!-- Cylinder Simulation -->
    <?php if ($result && $result->num_rows > 0): 
        $status = getStatusMessage($level);
    ?>
        <div class="text-center">
            <div class="cylinder">
                <div class="gas-fill" style="height: <?= $level ?>%;"></div>
            </div>
            <div class="cylinder-label"><?= $level ?>%</div>
            <div class="mt-2">
                <span class="badge bg-<?= $status['class'] ?>"><?= $status['msg'] ?></span>
            </div>
            <!-- Actions -->
            <form method="POST" style="display:inline-block;">
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <button type="submit" name="use" class="btn btn-warning mt-3">Use Gas</button>
            </form>
            <form method="POST" style="display:inline-block;">
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <button type="submit" name="refill" class="btn btn-success mt-3">Refill</button>
            </form>
            <form method="POST" style="display:inline-block;">
                <button type="submit" name="test_email" class="btn btn-info mt-3">Send Test Email</button>
            </form>
        </div>
    <?php endif; ?>

    <!-- History Table -->
    <h3 class="mt-4">Gas Usage History</h3>
    <?php
    $history = $conn->query("SELECT * FROM gas_meter WHERE user_id = $user_id ORDER BY updated_at DESC");
    if ($history && $history->num_rows > 0) {
        echo '<table class="table table-bordered table-striped">';
        echo '<thead><tr><th>ID</th><th>Level (%)</th><th>Last Notified</th><th>Updated At</th></tr></thead><tbody>';
        while ($hrow = $history->fetch_assoc()) {
            echo '<tr>';
            echo '<td>'.$hrow['id'].'</td>';
            echo '<td>'.$hrow['current_level'].'%</td>';
            echo '<td>'.($hrow['last_notified'] ?? '—').'</td>';
            echo '<td>'.$hrow['updated_at'].'</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<div class="alert alert-info">No gas history found.</div>';
    }
    ?>
<?php
$content = ob_get_clean();
renderLayout("Gas Levels", $content);
