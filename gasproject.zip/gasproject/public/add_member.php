<?php
// ✅ Show errors during development (remove on production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

require_once dirname(__DIR__) . '/src/db.php';
require_once dirname(__DIR__) . '/src/layout.php';

$success = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = $_POST['name'];
    $location = $_POST['location'];
    $phone    = $_POST['phone'];
    $email    = $_POST['email'];
    $meter_no = $_POST['meter_no'];

    // Default password
    $defaultPassword = 'member123';
    $hashedPassword  = password_hash($defaultPassword, PASSWORD_DEFAULT);

    // ✅ Insert into members (timestamps handled automatically)
    $sql = "INSERT INTO members (name, location, phone, email, meter_no, password) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed (members): " . $conn->error);
    }
    $stmt->bind_param("ssssss", $name, $location, $phone, $email, $meter_no, $hashedPassword);

    if ($stmt->execute()) {
        $memberId = $conn->insert_id;

        // ✅ Create default gas meter record
        $defaultLevel = 100; 
        $now = date('Y-m-d H:i:s');
        $sqlMeter = "INSERT INTO gas_meter (user_id, current_level, last_notified, updated_at) 
                     VALUES (?, ?, ?, ?)";
        $stmt2 = $conn->prepare($sqlMeter);
        if (!$stmt2) {
            die("Prepare failed (gas_meter): " . $conn->error);
        }
        $stmt2->bind_param("iiss", $memberId, $defaultLevel, $now, $now);
        $stmt2->execute();
        $stmt2->close();

        $success = "✅ Member added successfully! Default password: <b>$defaultPassword</b> (Gas level initialized to 100%)";
    } else {
        $error = "Error adding member: " . $stmt->error;
    }

    $stmt->close();
}

// ✅ Build page content
$content = '<h2>Add New Member</h2>';
if ($success) $content .= '<div class="alert alert-success">'.$success.'</div>';
if ($error)   $content .= '<div class="alert alert-danger">'.$error.'</div>';

$content .= '
<form method="POST" class="row g-3">
  <div class="col-md-6">
    <label class="form-label">Name</label>
    <input type="text" name="name" class="form-control" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Location</label>
    <input type="text" name="location" class="form-control" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Phone</label>
    <input type="text" name="phone" class="form-control" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Email</label>
    <input type="email" name="email" class="form-control" required>
  </div>
  <div class="col-md-6">
    <label class="form-label">Meter No</label>
    <input type="text" name="meter_no" class="form-control" required>
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Add Member</button>
  </div>
</form>
';

renderLayout("Add Member", $content);
