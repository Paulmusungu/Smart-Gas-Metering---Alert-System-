-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2025 at 09:40 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gas_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `gas_meter`
--

CREATE TABLE `gas_meter` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `current_level` int(11) NOT NULL DEFAULT 100,
  `last_notified` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gas_meter`
--

INSERT INTO `gas_meter` (`id`, `user_id`, `current_level`, `last_notified`, `updated_at`) VALUES
(1, 1, 100, NULL, '2025-08-19 08:34:01'),
(2, 4, 80, '2025-08-19 07:55:27', '2025-08-19 09:35:50'),
(3, 2, 60, NULL, '2025-08-19 10:29:58'),
(4, 5, 70, '2025-08-19 09:30:56', '2025-08-19 10:33:25');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `meter_no` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `location`, `phone`, `meter_no`, `password`, `created_at`, `updated_at`) VALUES
(1, 'paul', 'bahati', '0723369176', '2317', '$2y$10$5dY//t4RZeAWUAbS5nCiPOgR28Q.dxos5WSXPmkcKCp.A2dxMhmei', '2025-08-16 14:05:23', '2025-08-16 15:07:01'),
(2, 'Gianna', 'Butere', '0712758509', '1195', '$2y$10$1uvDI0umQr2xUdAab6OW/.MaW0vPHWEvoOz1ojkrqIHOS1p5eE0na', '2025-08-16 14:29:59', '2025-08-16 15:32:25'),
(4, 'member', 'mombasa', '0721345687', '1234', '$2y$10$Qnt7SiNhI6xxnXe5p.ryGelZxPyaAlvRp9UmJrPv49J1FXbhDORdS', '2025-08-19 04:55:27', '2025-08-19 06:04:37'),
(5, 'xyz', 'mazrui', '6474784', '4321', '$2y$10$.qFXggehiy6UVc/qvwauGuVITbEko.pRUBY/5WGmnv9PZMtAJcqhK', '2025-08-19 06:30:56', '2025-08-19 07:33:03');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `meter_id` int(11) NOT NULL DEFAULT 1,
  `threshold` int(11) NOT NULL,
  `message` varchar(500) DEFAULT NULL,
  `sent_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `meter_id`, `threshold`, `message`, `sent_at`) VALUES
(1, 1, 75, 'Alert: Gas level is at 75% or below. Please refill soon.', '2025-08-08 17:34:57'),
(2, 1, 75, 'Alert: Gas level is at 75% or below. Please refill soon.', '2025-08-08 17:39:30'),
(3, 1, 50, 'Alert: Gas level is at 50% or below. Please refill soon.', '2025-08-08 17:39:30'),
(4, 1, 25, 'Gas level is now at 23% (threshold 25%)', '2025-08-08 19:28:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gas_meter`
--
ALTER TABLE `gas_meter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_gas_meter_user` (`user_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `meter_no` (`meter_no`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gas_meter`
--
ALTER TABLE `gas_meter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gas_meter`
--
ALTER TABLE `gas_meter`
  ADD CONSTRAINT `fk_gas_meter_user` FOREIGN KEY (`user_id`) REFERENCES `members` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
