function updateUI(data) {
  const bar = document.getElementById('levelBar');
  bar.style.width = data.current_level + '%';
  bar.textContent = data.current_level + '%';
  document.getElementById('lastUpdated').textContent = 'Updated: ' + data.updated_at;
  const list = document.getElementById('notifications');
  list.innerHTML = '';
  const last = data.last_notified ? data.last_notified.split(',') : [];
  if (last.length === 0 || (last.length === 1 && last[0] === '')) {
    list.innerHTML = '<li class="list-group-item">No notifications sent yet.</li>';
  } else {
    last.sort((a,b)=>b-a).forEach(t => {
      const li = document.createElement('li');
      li.className = 'list-group-item';
      li.textContent = 'Notified at: ' + t + '%';
      list.appendChild(li);
    });
  }
}
async function fetchStatus() {
  try {
    const res = await fetch('api.php?action=status');
    const data = await res.json();
    updateUI(data);
  } catch (e) {
    console.error(e);
  }
}
fetchStatus();
setInterval(fetchStatus, 5000);
document.getElementById('refillBtn').addEventListener('click', async function(){
  await fetch('api.php?action=refill');
  fetchStatus();
});

document.getElementById('useBtn').addEventListener('click', async function(){
  const usage = document.getElementById('usageInput').value;
  if (!usage || usage <= 0) {
    alert("Enter a valid percentage");
    return;
  }
  await fetch('api.php?action=use', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'usage=' + encodeURIComponent(usage)
  });
  document.getElementById('usageInput').value = '';
  fetchStatus();
});
