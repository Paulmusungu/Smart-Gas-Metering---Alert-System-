<?php
return [
    'db' => [
        'host' => '127.0.0.1',
        'dbname' => 'tymmzere_gas_project',
        'user' => 'tymmzere_dbuser',
        'pass' => 'Webstack@2025',
        'charset' => 'utf8mb4'
    ],
    'thresholds' => [75, 50, 25],

    // Added to avoid "Undefined index: notifications"
    'notifications' => [],

    'sms_provider' => 'africastalking',
    'twilio' => [
        'sid' => 'TWILIO_SID',
        'token' => 'TWILIO_AUTH_TOKEN',
        'from' => '+1XXXXXXXXX'
    ],
    'africastalking' => [
        'username' => 'AT_USERNAME',
        'apiKey' => 'AT_API_KEY',
        'from' => 'GasAlert'
    ],
    'recipients' => '+2547XXXXXXXX,+2547YYYYYYYY'
];
