<?php
// src/layout.php
function renderLayout($title, $content) {
    // Find current file name (to highlight active link)
    $current_page = basename($_SERVER['PHP_SELF']);

    // Pull user details if logged in
    $username = $_SESSION['username'] ?? 'Guest';
    $meter_no = $_SESSION['meter_number'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($title) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body { 
      display: flex; 
      min-height: 100vh; 
      margin: 0; 
      background-color: #87CEEB; /* 🌟 Sky Blue background */
    }
    .sidebar {
      width: 240px; 
      background: #343a40; 
      color: #fff; 
      padding: 20px 15px;
    }
    .sidebar h4 {
      margin-bottom: 15px;
      font-size: 1.2rem;
    }
    .sidebar small {
      display: block;
      color: #bbb;
      margin-bottom: 20px;
    }
    .sidebar a {
      display: block; 
      padding: 10px 15px; 
      color: #ddd; 
      text-decoration: none;
      border-radius: 6px;
    }
    .sidebar a.active, .sidebar a:hover {
      background: #495057; 
      color: #fff;
    }
    .content { 
      flex: 1; 
      padding: 20px; 
      background: rgba(255, 255, 255, 0.85); /* optional: make content readable */
      border-radius: 8px;
      margin: 15px;
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h4 class="text-white">Gas Project</h4>
    <small>User: <?= htmlspecialchars($username) ?><br>
           Meter: <?= htmlspecialchars($meter_no) ?></small>
    
    <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>">Dashboard</a>
    <a href="add_member.php" class="<?= $current_page == 'add_member.php' ? 'active' : '' ?>">Add Member</a>
    <a href="view_members.php" class="<?= $current_page == 'view_members.php' ? 'active' : '' ?>">View Members</a>
    <a href="gas_levels.php" class="<?= $current_page == 'gas_levels.php' ? 'active' : '' ?>">Gas Levels</a>
    <hr>
    <a href="change_password.php" class="<?= $current_page == 'change_password.php' ? 'active' : '' ?>">Change Password</a>
    <a href="logout.php">🚪 Logout</a>
  </div>

  <!-- Page Content -->
  <div class="content">
    <h2><?= htmlspecialchars($title) ?></h2>
    <?= $content ?>
  </div>
</body>
</html>
<?php
}
?>
