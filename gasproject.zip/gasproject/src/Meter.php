<?php
class Meter {
    private $pdo;
    private $thresholds;
    private $config;

    public function __construct(PDO $pdo, array $thresholds, array $config) {
        $this->pdo = $pdo;
        $this->thresholds = $thresholds;
        $this->config = $config;
    }

    public function getState() {
        $stmt = $this->pdo->query('SELECT * FROM gas_meter WHERE id = 1');
        return $stmt->fetch();
    }

    public function updateLevel(int $newLevel) {
        // Update the gas level
        $stmt = $this->pdo->prepare('UPDATE gas_meter SET current_level = ?, updated_at = NOW() WHERE id = 1');
        $stmt->execute([$newLevel]);

        // Now check thresholds
        $state = $this->getState();
        $alreadyNotified = $state['last_notified'] ? explode(',', $state['last_notified']) : [];

        foreach ($this->thresholds as $threshold) {
            if ($newLevel <= $threshold && !in_array($threshold, $alreadyNotified)) {
                // Send simulated SMS
                sendSms($this->config, "⛽ Gas level is now at $newLevel%. Please refill soon.");

                // Record this notification in DB
                $alreadyNotified[] = $threshold;
                $upd = $this->pdo->prepare('UPDATE gas_meter SET last_notified = ? WHERE id = 1');
                $upd->execute([implode(',', $alreadyNotified)]);
            }
        }
    }

    public function recordNotification(int $threshold, string $message) {
        $ins = $this->pdo->prepare('INSERT INTO notifications (meter_id, threshold, message) VALUES (1, ?, ?)');
        $ins->execute([$threshold, $message]);
        $state = $this->getState();
        $last = $state['last_notified'] ? explode(',', $state['last_notified']) : [];
        if (!in_array($threshold, $last)) {
            $last[] = $threshold;
            $upd = $this->pdo->prepare('UPDATE gas_meter SET last_notified = ? WHERE id = 1');
            $upd->execute([implode(',', $last)]);
        }
    }
}
