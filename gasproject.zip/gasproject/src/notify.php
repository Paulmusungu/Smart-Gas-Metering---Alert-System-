<?php
function sendSms($config, $message, $meter_id = null, $threshhold = null, $conn = null) {
    // Show simulated SMS as a popup
    echo "<script>alert('📲 SIMULATED SMS: " . addslashes($message) . "');</script>";

    // Also log the message to a file
    file_put_contents(__DIR__ . '/../sms_log.txt',
        date('Y-m-d H:i:s') . " | " . $message . "\n",
        FILE_APPEND
    );

    // ✅ Insert into notifications table
    if ($conn && $meter_id) {
        $msg = $conn->real_escape_string($message);
        $conn->query("
            INSERT INTO notifications (meter_id, threshold, message, sent_at)
            VALUES ($meter_id, ".intval($threshhold).", '$msg', NOW())
        ");
    }
}
