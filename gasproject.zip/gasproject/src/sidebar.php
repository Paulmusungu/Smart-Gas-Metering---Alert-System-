<div class="bg-dark text-white p-3" style="min-width:220px; min-height:100vh;">
  <h4 class="mb-4">Gas Project</h4>
  <ul class="nav flex-column">
    <li class="nav-item mb-2">
      <a class="nav-link text-white" href="dashboard.php">🏠 Dashboard</a>
    </li>
    <li class="nav-item mb-2">
      <a class="nav-link text-white" href="add_member.php">➕ Add Member</a>
    </li>
    <li class="nav-item mb-2">
      <a class="nav-link text-white" href="view_members.php">👥 View Members</a>
    </li>
    <li class="nav-item mb-2">
      <a class="nav-link text-white" href="gas_levels.php">📊 Gas Levels</a>
    </li>
    <li class="nav-item mt-4">
      <a class="nav-link text-danger" href="logout.php">🚪 Logout</a>
    </li>
  </ul>
</div>
